/*
TO DO:

1. forbid translation to PXLCOORD
*/
#include <cstddef>
#include <vector>
#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <memory>
#include <climits>
//#include "OrthoView.h"
#include "Geometry.h"
#include "Config.h"
#include "AEL.h"
#include "Shader.h"
#include "Matrix.h"
#include "WindowManager.h"
#include "Edge.h"
#include "Face.h"

//extern OrthoView* OrthoView;
extern WindowManager* winMan;
extern Shader* shader;
extern Config progConfig;



Geometry::Geometry(){
	centroid = Vertex();
}

Geometry::Geometry(const Geometry& geo){

	geoType = geo.geoType;
	unitType = geo.unitType;
	centroid = geo.centroid;
	
	for (auto v: geo.vertices)
		vertices.push_back(std::shared_ptr<Vertex>(new Vertex(*v.get())));

}


Geometry::~Geometry(){
}

int Geometry::getID()const{
	return shader->geoGetN(this);
}


Vertex Geometry::getCentroid()const{
	return centroid;
}

void Geometry::updateCentroid(){

	float xSum = 0;
	float ySum = 0;
	float zSum = 0;

	for ( auto v: vertices){
		xSum += v->getX();
		ySum += v->getY();
		zSum += v->getZ();
	}
	std::cout << "centroid: " << xSum << " "  << ySum << " "  << zSum <<std::endl;  
	//if ( sqrt( pow( ret.getX() - centroid.getX() , 2) + pow( ret.getY() - centroid.getY() , 2) ) > 1) 
		//centroid = ret;
	centroid = Vertex(xSum / static_cast<float>(size()), ySum / static_cast<float>(size()), zSum / static_cast<float>(size()));

}

void Geometry::transform(const Matrix& tm){
	// construct matri
	Matrix m (4, size());
	//Matrix result;
	for (unsigned int vCnt = 0; vCnt < size(); vCnt++){
		m[vCnt][0] = vertices[vCnt]->getX();
		m[vCnt][1] = vertices[vCnt]->getY();
		m[vCnt][2] = vertices[vCnt]->getZ();
		m[vCnt][3] = 1;
	}
	Matrix result = tm * m;

	for (unsigned int vCnt = 0; vCnt < size(); vCnt++){
		vertices[vCnt]->setX(result[vCnt][0]);
		vertices[vCnt]->setY(result[vCnt][1]);
		vertices[vCnt]->setZ(result[vCnt][2]);
	}

}

void Geometry::operator+=(const std::shared_ptr<Vertex> &v)
{
	vertices.push_back( v );

	if (vertices.size() <= 3)
		geoType = static_cast<GeoType>(vertices.size());
}


void Geometry::operator+=(const std::shared_ptr<Edge> &e){
	edges.push_back( e );
}


void Geometry::operator+=(const std::shared_ptr<Face> &f){
	faces.push_back( f );
}

void Geometry::clear(){
	vertices.clear();
	edges.clear();
}


/*
*/
void Geometry::toPXLPOS(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z){
	if(isType(PXLPOS))
		return;
	
	unitType = PXLPOS;
	for (auto vertex : vertices)
		vertex->toPXLPOS(pixelUnit, w_x, w_y, w_z);
}


std::string Geometry::save(){
	std::string str="";

	// dumping vertexes
	for (int i = 0; i < 3; i++)
		str.append(std::to_string(color[i]) + " ");

	str.append("\n");

	str.append(std::to_string(size()) + "\n" );
	for (auto vertex : vertices){
		str.append(std::to_string(vertex->getX()) + " " );
		str.append(std::to_string(vertex->getY()) + " " );
		str.append(std::to_string(vertex->getZ()) + "\n" );
	}
	str.append("\n" );

	// dumping edges 
	str.append(std::to_string(edges.size()) + "\n" );
	for (auto edge : edges){
		str.append(std::to_string(vGetN(*edge->getHead())) + " " );
		str.append(std::to_string(vGetN(*edge->getTail())) + "\n" );
	}
	str.append("\n" );

	// dumping faces 
	str.append(std::to_string(faces.size()) + "\n" );
	for (auto face : faces){
		str.append(std::to_string(vGetN(*face->getV(0))) + " " );
		str.append(std::to_string(vGetN(*face->getV(1))) + " " );
		str.append(std::to_string(vGetN(*face->getV(2))) + "\n" );
	}
	str.append("\n" );

	return str;
}

int Geometry::vGetN(const Vertex &v)const{
	for ( unsigned int i = 0; i < vertices.size(); i++ )
		if ( v == *vertices[i].get() )
			return i;

	return -1;
}


std::shared_ptr<Vertex> Geometry::nGetV(const unsigned int& index){
	if (index >= vertices.size())
		return std::shared_ptr<Vertex>(nullptr);
	else
		return vertices[index];
}

void Geometry::draw()const
{
	float *c;
	
	if ( getID() == progConfig.curSelected)
		c = progConfig.COLOR_hlStroke;
	else
		c = progConfig.COLOR_regStroke;

	drawLines(c);

}

void Geometry::drawNormal()const{

	for (auto face: faces){
		winMan->drawLine(face->getCentroid(), 
						static_cast<Vertex>(face->getCentroid() + face->getNormalVector()/2 ), progConfig.COLOR_regStroke);
	}

	for (auto v: vertices){
		Vertex normal (getNormalVector(*v));
		if (normal != Vertex(0.0f, 0.0f, 0.0f))
			winMan->drawLine(*v, *v+normal / 2, progConfig.COLOR_regStroke);
	}
}



void Geometry::drawLines(float* c)const{
//if there is only one vertex
	if (vertices.size() == 0)
		return;
	if (vertices.size() == 1)
	{
		winMan->setPix(static_cast<const Vertex*>(vertices[0].get()), c);
		return;
	}

	for (auto edge: edges)
		winMan->drawLine(*edge->getHead(), *edge->getTail(), c);
	
}

/*
Geometry Geometry::inPXLCOORD(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z)const{
	Geometry ret(*this);
	ret.toPXLPOS(pixelUnit, w_x, w_y, w_z);
	return ret;
}

std::vector<AEL*> Geometry::getAELs(){
	if ( isType(COORDS) )
	{
		std::cout << "ERROR: Calling Geometry::getAELs() with type COORD. Ignore" << std::endl;
		return std::vector<AEL*>();
	}

	if ( vertices.size() <= 2)
		return std::vector<AEL*>();




	vertices.push_back(vertices[0]);
	std::vector<AEL*> ret;
	for (unsigned int i = 0; i < vertices.size() - 1; i++){
		Vertex *v1, *v2;
		if ( vertices[i]->getY() == vertices[i+1]->getY())
			continue;
		else if (vertices[i]->getY() > vertices[i+1]->getY()){
			v1 = vertices[i].get();
			v2 = vertices[i+1].get();
		} 
		else {
			v1 = vertices[i+1].get();
			v2 = vertices[i].get();
		}
		// v1 has higher y value

		float x1 = v1->getX(), x2 = v2->getX(), y1 = v1->getY(), y2 = v2->getY();

		ret.push_back(new AEL(x1, y1, -(x1 - x2)/(y1 - y2), y2 ));


	}

	sort(ret.begin(), ret.end(), compare );
	vertices.pop_back();

	return ret;
}
*/


void Geometry::transpose(){
	for (auto v: vertices){
		float temp = v->getX();
		v->setX(v->getY());
		v->setY(temp);
	}
}

// should be passing in pixel coordinate value
void Geometry::clip(const Vertex& v){

	// convert unit;
	if (progConfig.clipMode == UP)
		clipUP(v.getY());
	else if (progConfig.clipMode == DOWN)
		clipDOWN(v.getY());	
	else if (progConfig.clipMode == LEFT)
		clipLEFT(v.getX());
	else if (progConfig.clipMode == RIGHT)
		clipRIGHT(v.getX());
}

void Geometry::clipUP(const float& y){
	// for each line 
	vertices.push_back(vertices[0]);

	std::vector<std::shared_ptr<Vertex>>  newVs;
	bool hasKeptLast = false;
	// for every line
	for ( unsigned int i = 0; i < vertices.size()-1; i++){
		std::shared_ptr<Vertex> v1 = vertices[i];
		std::shared_ptr<Vertex>	v2 = vertices[i+1];
		std::shared_ptr<Vertex>	intersect = getHorizontalIntersection(*v1, *v2, y);
		if (intersect == nullptr){
			if (v1->getY() < y ){
				if (!hasKeptLast)
					newVs.push_back(std::shared_ptr<Vertex>( v1));
				newVs.push_back(std::shared_ptr<Vertex>( v2));
				hasKeptLast = true;
				continue;
			}
			else{
				hasKeptLast = false;
				continue;
			} 
		}
		else{
			if (v1->getY() < y ){
				if (!hasKeptLast)
					newVs.push_back(std::shared_ptr<Vertex>(v1));
				newVs.push_back(intersect);
				hasKeptLast = false;
				continue;
			}
			else{

				newVs.push_back(intersect);
				newVs.push_back(std::shared_ptr<Vertex>(v2));
				hasKeptLast = true;
				continue;
			} 	
		}
	}

	
	if (newVs.size() == 0)
	{
		progConfig.curSelected=0;
		shader->deleteGeo(this);
		return;
	}
	else{
		if(hasKeptLast)
			newVs.pop_back();
		vertices.clear();
		for (auto v: newVs){
			//v->print();
			vertices.push_back(v);
		}
	}
}

void Geometry::clipDOWN(const float&y){
	// for each line 
	vertices.push_back(vertices[0]);
//	std::cout << "Here" << std::endl;
	std::vector<std::shared_ptr<Vertex>> newVs;
	bool hasKeptLast = false;
	// for every line
	for ( unsigned int i = 0; i < vertices.size()-1; i++){
		std::shared_ptr<Vertex> v1 = vertices[i];
		std::shared_ptr<Vertex>	v2 = vertices[i+1];
		std::shared_ptr<Vertex>	intersect = getHorizontalIntersection(*v1, *v2, y);
		if (intersect == nullptr){
			if (v1->getY() > y ){
				if (!hasKeptLast)
					newVs.push_back(std::shared_ptr<Vertex>( v1));
				newVs.push_back(std::shared_ptr<Vertex>( v2));
				hasKeptLast = true;
				continue;
			}
			else{
				hasKeptLast = false;
				continue;
			} 
		}
		else{
			if (v1->getY() > y ){
				if (!hasKeptLast)
					newVs.push_back(std::shared_ptr<Vertex>( v1 ));
				newVs.push_back(intersect);
				hasKeptLast = false;
				continue;
			}
			else{

				newVs.push_back(intersect);
				newVs.push_back(std::shared_ptr<Vertex>(v2));
				hasKeptLast = true;
				continue;
			} 	
		}
	}

	if (newVs.size() == 0)
	{
		progConfig.curSelected = 0;
		shader->deleteGeo(this);
		return;
	}
	else{

		if(hasKeptLast)
			newVs.pop_back();
		vertices.clear();
		for (auto v: newVs){
			//v->print();
			vertices.push_back(v);
		}
	}
	
}

void Geometry::clipLEFT(const float& x){
	transpose();
	clipDOWN(x);
	transpose();

}

void Geometry::clipRIGHT(const float&x){
	transpose();
	clipUP(x);
	transpose();
}


std::shared_ptr<Vertex> Geometry::getHorizontalIntersection(const Vertex& v1, const Vertex& v2, const float& y){
	float x1 = v1.getX(),
	 	  x2 = v2.getX(), 
	 	  y1 = v1.getY(), 
	 	  y2 = v2.getY();

	if ( (y1 < y && y2 < y) || (y1 > y && y2 > y) )
		return nullptr;

	float m = (x2 - x1) / (y2 - y1);

	float x = m*(y - y1) + x1;

	return std::shared_ptr<Vertex>( new Vertex(x, y, 0) );

}


std::shared_ptr<Vertex> Geometry::getVerticalIntersection(const Vertex& v1, const Vertex& v2, const float& x){
	float x1 = v1.getX(),
	 	  x2 = v2.getX(), 
	 	  y1 = v1.getY(), 
	 	  y2 = v2.getY();

	if ( (x1 < x && x2 < x) || (x1 > x && x2 > x) )
		return nullptr;

	float m = (y2 - y1) / (x2 - x1);

	float y = m*(x - x1) + y1;

	return std::shared_ptr<Vertex>( new Vertex(x, y, 0) );
}

float Geometry::getMaxX()const{
	float ret = std::numeric_limits<float>::lowest();
	for (auto v: vertices)
		if (v->getX() > ret)
			ret = v->getX();

	return ret;
}

float Geometry::getMinX()const{
	float ret = std::numeric_limits<float>::max();
	for (auto v: vertices)
		if (v->getX() < ret)
			ret = v->getX();

	return ret;
}

float Geometry::getMaxY()const{
	float ret = std::numeric_limits<float>::lowest();
	for (auto v: vertices)
		if (v->getY() > ret)
			ret = v->getY();

	return ret;
}

float Geometry::getMinY()const{
	float ret = std::numeric_limits<float>::max();
	for (auto v: vertices)
		if (v->getY() < ret)
			ret = v->getY();

	return ret;
}

float Geometry::getMaxZ()const{
	float ret = std::numeric_limits<float>::lowest();
	for (auto v: vertices)
		if (v->getZ() > ret)
			ret =v->getZ();

	return ret;
}

float Geometry::getMinZ()const{
	float ret = std::numeric_limits<float>::max();
	for (auto v: vertices)
		if (v->getZ() < ret)
			ret = v->getZ();

	return ret;
}

Vertex Geometry::getNormalVector(const Vertex& v)const{
	if(vGetN(v) == -1)
		return Vertex(0.0, 0.0, 0.0);
	float faceCnt = 0.0f;
	Vertex normal;
	for (auto face:faces){
		if (face->hasVertex(v)){
			faceCnt++;
			normal = normal + face->getNormalVector();
		}
	}
	return normal/faceCnt;
}


void Geometry::computeColors(const Vertex & lightSource, const Vertex &viewPtr){
	colors.clear();

	for (auto p: vertices){

		double ka = 0.3, kd=0.8, ks=0.5, n = 3.0;
		double c = 3;
		Vertex normal = getNormalVector(*p).makeUnitVector();
		Vertex l = (lightSource - *p).makeUnitVector();
		Vertex v = (viewPtr - *p).makeUnitVector();
		Vertex r = (l) - (n*(2*normal.dot(l)));
		double cosalpha = normal.dot(lightSource);
		double cosbeta = v.dot(r);

		if (cosalpha < 0)
			cosalpha = 0;
		if (cosbeta < 0)
			cosbeta = 0;

		Vertex Ia (getColor());
		Vertex Il (1.0f, 1.0f, 1.0f);
		p->setColor( Ia*ka + ( Il.times(Ia)/((viewPtr - v).length() + c ) )*(kd*cosalpha + ks*pow(cosbeta, n)) );
	}

}


// // if colors is empty, have to call computeColors from Shader.
// std::vector<Vertex> Geometry::getColors(const Face & face)const {
// 	std::vector<Vertex> ret;
// 	for (auto v:face.getVertices()){
// 		ret.push_back(colors[vGetN(*v)]);
// 	}
// 	return ret;
// }


float Geometry::getHighestColor()const{
	float max = std::numeric_limits<float>::min();
	for(auto v :vertices)
	{
		for (int i = 0; i < 3; i++){
			if(v->getColor()[i] > max)
				max = v->getColor()[i];
		}
	}
	return max;
}

void Geometry::normalizeColors(const float &colorRate){
	for (auto v:vertices)
		v->setColor(v->getColor()[R]*colorRate, v->getColor()[G]*colorRate, v->getColor()[B]*colorRate);
}

void Geometry::setColor(const float& r, const float& g, const float& b){
	color[R] = r;
	color[G] = g;
	color[B] = b;
}

Vertex Geometry::getColor()const{
	return Vertex(color[R], color[G], color[B]);
}

std::ostream& operator << (std::ostream& stream, const Geometry& geo){
	stream << "ID: " << shader->geoGetN(&geo) << std::endl;
	for( auto v: geo.vertices){
		stream << *v << std::endl;;
	
	} 
	return stream;
}
