#include <cmath>

#include "Vertex.h"
#include "Edge.h"


Edge::Edge(const Edge& e){
	if ( e.head != nullptr )
		head = std::shared_ptr<Vertex>( new Vertex( *e.head ));
	if ( e.tail != nullptr )
		tail = std::shared_ptr<Vertex>( new Vertex( *e.tail ));
}

void Edge::makeUnitVector(){
	double len = length();
	//*head = (*head)*(1/len);
	
	*tail = *tail - *head;
	*tail = *tail*(1/len);
	*tail = *tail + *head;
}

double Edge::length(){
	return sqrt( pow(tail->getX() - head->getX(), 2) + pow(tail->getY() - head->getY(), 2) + pow(tail->getZ() - head->getZ(), 2) );
}