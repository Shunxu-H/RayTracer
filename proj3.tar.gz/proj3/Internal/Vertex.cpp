#include <iostream>
#include <cmath>
#include <cstring>
#include "Vertex.h"
#include "OrthoView.h"
#include "WindowManager.h"
#include "Matrix.h"
#include "Index.h"


extern WindowManager *winMan;

Vertex::Vertex(const float &_x, const float &_y, const float &_z):Matrix(3,1){
	data[0][X] = _x;
	data[0][Y] = _y; 
	data[0][Z] = _z;
	color[R] = 0.0f;
	color[G] = 0.0f;
	color[B] = 0.0f;
	// /color = nullptr;
}
	
Vertex::Vertex(const Matrix &rhs):Matrix(rhs){
	color[R] = 0.0f;
	color[G] = 0.0f;
	color[B] = 0.0f;
	//color = nullptr;
}
Vertex::Vertex(const Vertex &rhs):Matrix(rhs){
	memcpy(color, rhs.color, sizeof(float[3]));
	// if (rhs.color != nullptr)
	// 	color = new Vertex(*rhs.color);
}

Vertex::~Vertex(){
// 	if (color != nullptr)
// 		delete color;
}	



void Vertex::toCOORDS(const float& pixelUnit, const float &w_x, const float& w_y, const float& w_z){
	(*this)[X] = (*this)[X]/pixelUnit + w_x;
	(*this)[Y] = (*this)[Y]/pixelUnit + w_y;
	(*this)[Z] = (*this)[Z]/pixelUnit + w_z;
	//std::cout << x << " " << y << std::endl;
}

void Vertex::toPXLPOS(const float& pixelUnit, const float &w_x, const float& w_y, const float& w_z){
	(*this)[X] = ((*this)[X] - w_x)*pixelUnit;
	(*this)[Y] = ((*this)[Y] - w_y)*pixelUnit;
	(*this)[Z] = ((*this)[Z] - w_z)*pixelUnit;	
}

Vertex Vertex::inCOORDS(const float& pixelUnit, const float &w_x, const float& w_y, const float& w_z)const{
	return Vertex((*this)[X]/pixelUnit + w_x, (*this)[Y]/pixelUnit + w_y, (*this)[Z]/pixelUnit + w_z);
}

Vertex Vertex::inPXLPOS(const float& pixelUnit, const float &w_x, const float& w_y, const float& w_z)const{
	return Vertex(((*this)[X] - w_x)*pixelUnit, ((*this)[Y] - w_y)*pixelUnit, ((*this)[Z] - w_z)*pixelUnit);
}

void Vertex::transform(const Matrix& tm)
{

	Matrix m (4, 1);
	//Matrix result;
	m[0][0] = getX();
	m[0][1] = getY();
	m[0][2] = getZ();
	m[0][3] = 1;
	

	Matrix result = tm * m;

	(*this)[X] = result[0][0];
	(*this)[Y] = result[0][1];
	(*this)[Z] = result[0][2];
	
}

/*
Vertex Vertex::operator*(const float& n)const{
	float x = (*this)[X] * n;
	float y = (*this)[Y] * n;
	float z = (*this)[Z] * n;
	return Vertex(x, y, z);
}


Vertex Vertex::operator+(const Vertex& rhs)const{
	float x = (*this)[X] + rhs.(*this)[X];
	float y = (*this)[Y] + rhs.(*this)[X];
	float z = (*this)[Z] + rhs.(*this)[X];
	return Vertex(x, y, z);
}

Vertex Vertex::operator-(const Vertex& rhs)const{
	float x = (*this)[X] - rhs.(*this)[X];
	float y = (*this)[Y] - rhs.(*this)[X];
	float z = (*this)[Z] - rhs.(*this)[X];
	return Vertex(x, y, z);
}

*/
std::ostream& operator<< (std::ostream& stream, const Vertex& v){
	stream << "X: " << v[X] << "; " << "Y: " << v[Y] << "; " <<  "Z: " << v[Z] << "; ";
	return stream;
}

Vertex Vertex::cross(const Vertex& rhs)const{
	float i = (*this)[1]*rhs[2] - (*this)[2]*rhs[1];
	float j = (*this)[2]*rhs[0] - (*this)[0]*rhs[2];
	float k = (*this)[0]*rhs[1] - (*this)[1]*rhs[0];
	return Vertex(i, j, k);
}

double Vertex::length(){
	return sqrt( powf(getX(), 2.0f) + powf(getY(), 2.0f) + powf(getZ(), 2.0f) );
}

Vertex Vertex::makeUnitVector(){
	double len = length();

	return Vertex(getX()/len, getY()/len , getZ()/len);
}

void Vertex::setColor(const float& r , const float& g, const float& b){
	color[R] = r;
	color[G] = g;
	color[B] = b;
}

void Vertex::setColor(const Vertex& c){
	color[R] = c[R];
	color[G] = c[G];
	color[B] = c[B];
}

Vertex Vertex::getColor()const{
	return Vertex(color[R], color[G], color[B]);
}