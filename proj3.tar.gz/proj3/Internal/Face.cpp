#include <vector>
#include <memory>
#include <algorithm>
#include "Vertex.h"
#include "Face.h"
#include "Utility.h"
#include "AEL.h"
#include "Shader.h"

extern Shader* shader;

Face::Face(){

}

Face::Face(const Face& f){
	for(auto v: f.vertices)
		vertices.push_back(std::shared_ptr<Vertex>(new Vertex(*v)));
}

Face::~Face(){
	
}


void Face::addV(std::shared_ptr<Vertex> v){
	vertices.push_back(v);
}


std::shared_ptr<Vertex> Face::getV(const unsigned int & index)const{
	if(index >= vertices.size())
		return std::shared_ptr<Vertex>(nullptr);
	else 
		return vertices[index];
}


void Face::toPXLPOS(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z){
	for (auto vertex : vertices)
		vertex->toPXLPOS(pixelUnit, w_x, w_y, w_z);
}

Face Face::inPXLCOORD(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z)const{
	Face ret(*this);
	ret.toPXLPOS(pixelUnit, w_x, w_y, w_z);
	return ret;
}

std::vector<AEL*> Face::getAELs(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z, const INDEX& axis1, const INDEX& axis2)const{
	Face f = inPXLCOORD(pixelUnit, w_x, w_y, w_z);

	f.vertices.push_back(f.vertices[0]);
	std::vector<AEL*> ret;
	for (unsigned int i = 0; i < f.vertices.size() - 1; i++){
		Vertex *v1, *v2;
		Vertex c1, c2;
		if ( (*f.vertices[i])[axis2] == (*f.vertices[i+1])[axis2])
			continue;
		else if ((*f.vertices[i])[axis2] > (*f.vertices[i+1])[axis2]){
			v1 = f.vertices[i].get();
			v2 = f.vertices[i+1].get();
		} 
		else {
			v1 = f.vertices[i+1].get();
			v2 = f.vertices[i].get();
		}
		// v1 has higher y value

		float x1 = (*v1)[axis1], x2 = (*v2)[axis1], y1 = (*v1)[axis2], y2 = (*v2)[axis2];

		ret.push_back(new AEL(x1, y1, -(x1 - x2)/(y1 - y2), y2 , v2->getColor(), v1->getColor()));


	}

	sort(ret.begin(), ret.end(), compare );
	
	return ret;
}


void Face::print(){
	std::cout << vertices.size() << std::endl;
	for(auto v: vertices)
		std::cout << *v << std::endl;
	std::cout << std::endl;
}



Vertex Face::getNormalVector(){
	return (*vertices[2] - *vertices[0]).cross((*vertices[1] - *vertices[0])).makeUnitVector();
}

Vertex Face::getCentroid(){
	float xSum = 0, ySum = 0, zSum = 0;
	for (auto v: vertices){
		xSum += v->getX();
		ySum += v->getY();
		zSum += v->getZ();
	}

	xSum /= vertices.size();
	ySum /= vertices.size();
	zSum /= vertices.size();
	
	return Vertex(xSum, ySum, zSum);
}


bool Face::hasVertex(const Vertex& rhs)const{
	for (auto v:vertices)
		if (*v.get() == rhs)
			return true;

	return false;
}