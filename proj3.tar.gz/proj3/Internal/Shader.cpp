#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <cstring>
#include <queue>
#include <limits>
#include <cmath>
#include <climits>
#include "Shader.h"
#include "Config.h"
#include "OrthoView.h"
#include "Edge.h"
#include "Geometry.h"
#include "WindowManager.h"
#include "Utility.h"
#include "Face.h"
#include "Vector.h"

extern Config progConfig;
extern Geometry* vertexBuffer;
extern WindowManager* winMan;


Shader::Shader(const std::string& file){
	lightSource = Vertex(0.0f, 100.0f, 0.0f);
	viewPtr = Vertex(0.0f, 0.0f, 2.0f); 
	//coordinate = new Coordinate();
	fileName = file;
	rotationVector = Edge( std::shared_ptr<Vertex>(new Vertex(0.0f, 0.0f, 0.0f)) , std::shared_ptr<Vertex>(new Vertex(1.0f, 1.0f, 1.0f)));
}

Shader::~Shader(){
	for (auto geo: geometries)
		delete(geo);
}



void Shader::addGeom( Geometry* newG ){
	if (!newG)
		return;
	if (newG->isType(PXLPOS)){
		std::cout << "ERROR: unconverted geometries being pushed.Ignore." << std::endl;
		return;
	}

	geometries.push_back(newG); 
}

void Shader::loadFile (const std::string& _fileName){
	std::fstream f;
	if (_fileName.size() > 0)
		f.open(_fileName.c_str());
	else 
		f.open(fileName.c_str());

	if (!f.is_open())
	{
		std::cerr << "ERROR: Can't open file " << fileName << std::endl;
		return;
	}

	std::stringstream fss;
	fss << f.rdbuf();

	f.close();
	
	std::deque<std::string> tokens = mystrtok( fss.str(), " \n");

	int vCnt = 0, eCnt = 0, fCnt = 0;

	while (!tokens.empty()){
		Geometry* newG = new Geometry();
		
		// load color
		newG->setColor(stof(tokens[R]), stof(tokens[G]), stof(tokens[B]));
		tokens.pop_front();
		tokens.pop_front();
		tokens.pop_front();
		
		// load vertexes
		vCnt = atoi( tokens.front().c_str());
		tokens.pop_front();
		for ( int i = 0; i < vCnt; i++){
			float x = stof(tokens.front());
			tokens.pop_front();
			float y = stof(tokens.front());
			tokens.pop_front();
			float z = stof(tokens.front());
			tokens.pop_front();

			*newG += std::shared_ptr<Vertex>( new Vertex(x, y, z) );
		}

		// load edges
		eCnt = atoi( tokens.front().c_str());
		tokens.pop_front();
		
		for ( int i = 0; i < eCnt; i++){
			
			int headItr = stoi(tokens.front());
			tokens.pop_front();
			int tailItr = stoi(tokens.front());
			tokens.pop_front();

			*newG += std::shared_ptr<Edge>( new Edge(newG->nGetV(headItr), newG->nGetV(tailItr)));
		}

		// load faces
		fCnt = atoi( tokens.front().c_str());
		tokens.pop_front();
		
		// assuming each face has exactly 3 vertices
		for ( int i = 0; i < fCnt; i++){
			std::shared_ptr<Face> newFace(new Face());
			
			newFace->addV(newG->nGetV(stoi(tokens.front())));
			tokens.pop_front();
			
			newFace->addV(newG->nGetV(stoi(tokens.front())));
			tokens.pop_front();
			
			newFace->addV(newG->nGetV(stoi(tokens.front())));
			tokens.pop_front();

			*newG += newFace;
		}

		
		newG->updateCentroid();
		addGeom(newG);
	}
	

	winMan->reshapeWindows();
	drawAll();

}


Geometry* Shader::getCurSelection()const{
	if(!progConfig.isValidSelection())
		return nullptr;

	return nGetGeo(progConfig.curSelected);
}


void Shader::clear(){
	for (auto geo: geometries){
		geo->clear();
		delete(geo);
	}
//std::cout << "clear" << std::endl;
	geometries.clear();
}


void Shader::deleteGeo(Geometry* g){
	std::vector<Geometry*>::iterator itr = geometries.begin();

	for( ; itr != geometries.end(); itr++){
		if (*itr == g)
		{
			geometries.erase(itr);
			return;
		}
	}
}


void Shader::save(const std::string& fileName){
	std::string str="";

	for ( auto geometry : geometries)	
		str.append(geometry->save());

	//std::cout <<  str << std::endl;
	std::ofstream ofs (fileName.c_str(), std::ofstream::out);

	if(!ofs.is_open())
		std::cerr << "Invalid fileName in Coordinate::save(const std::string& fileName)" << std::endl;

	ofs << str; 

	ofs.close();
}

float Shader::getColorNormalizeRate()const{
	float max = std::numeric_limits<float>::min();

	for (auto geo:geometries){
		float curMax = geo->getHighestColor();
		if(curMax > max)
			max = curMax;
	}

	return 1.0f/max;
}

void Shader::normalizeColors(const float& colorRate )const{

	for (auto geo:geometries){
		geo->normalizeColors(colorRate);
	}

}

void Shader::drawAll(){
	// compute all the colors
	for( auto geo: geometries)
		geo->computeColors(lightSource, viewPtr);
	normalizeColors(getColorNormalizeRate());

	if(progConfig.fillMode == FILL && progConfig.opMode != TRANSFORM ) {
		winMan->fillPolygons(geometries);
	}
	else if (progConfig.fillMode == HALFTONE){
		for (auto geo:geometries){
			winMan->halfToning(*geo);
		}
	}
	else {
		for (unsigned int i = 0; i < size(); i++){
			//geometries[i]->print();
			curRendering = geometries[i];
			geometries[i]->draw();
		}
	}


	// draw normals 
	if(progConfig.showNormal == true){	
		for (auto geo:geometries){
			geo->drawNormal();
		}
	
	}


	drawLight();
}


Geometry* Shader::nGetGeo(const unsigned int &index )const {
	if (index >= size())
		return nullptr;
	else 
		return geometries[index];
}

int Shader::geoGetN(const Geometry* geo)const {
	for ( unsigned int i = 0; i < geometries.size(); i++)
		if (geo == geometries[i] )
			return i;
	return -1;
}


float Shader::getMaxX()const{
	float ret = std::numeric_limits<float>::lowest();
	for (auto geo: geometries)
		if (geo->getMaxX() > ret)
			ret = geo->getMaxX();

	return ret;
}

float Shader::getMinX()const{
	float ret = std::numeric_limits<float>::max();
	for (auto geo: geometries)
		if (geo->getMinX() < ret)
			ret = geo->getMinX();

	return ret;
}

float Shader::getMaxY()const{
	float ret = std::numeric_limits<float>::lowest();
	for (auto geo: geometries)
		if (geo->getMaxY() > ret)
			ret = geo->getMaxY();

	return ret;
}

float Shader::getMinY()const{
	float ret = std::numeric_limits<float>::max();
	for (auto geo: geometries)
		if (geo->getMinY() < ret)
			ret = geo->getMinY();

	return ret;
}

float Shader::getMaxZ()const{
	float ret = std::numeric_limits<float>::lowest();
	for (auto geo: geometries)
		if (geo->getMaxZ() > ret)
			ret = geo->getMaxZ();

	return ret;
}

float Shader::getMinZ()const{
	float ret = std::numeric_limits<float>::max();
	for (auto geo: geometries)
		if (geo->getMinZ() < ret)
			ret = geo->getMinZ();

	return ret;
}


void Shader::print()const{
	for (auto geo: geometries)
		std::cout << *geo << std::endl;;
}

Vertex Shader::getColor(const Vertex& p)const{	
	double ka = 0.8, kd=0.8, ks=0.5, n = 3.0;
	double c = 3;
	Vertex normal = getNormalVector(p).makeUnitVector();
	Vertex l = (lightSource - p).makeUnitVector();
	Vertex v = (viewPtr - p).makeUnitVector();
	Vertex r = (l) - (n*(2*normal.dot(l)));
	double cosalpha = normal.dot(lightSource);
	double cosbeta = v.dot(r);

	Vertex Ia (1.0f, 0.0f, 0.0f);
	Vertex Il (1.0f, 1.0f, 1.0f);
	Matrix ret = Ia*ka + ( Il.times(Ia)/((viewPtr - v).length() + c ) )*(kd*cosalpha + ks*pow(cosbeta, n));

	return Vertex(ret);
}

Vertex Shader::getNormalVector(const Vertex& v)const{
	Vertex n = curRendering->getNormalVector(v);
	if ( n != Vertex(0.0f, 0.0f, 0.0f))
		return n;
	return Vertex(0.0f, 0.0f, 0.0f);

}


void Shader::drawLight()const{
	Vertex dir[27];

	for (int i = -1; i <= 1; i++){
		for (int j = -1; j <= 1; j++){
			for (int k = -1; k <= 1; k++){
				winMan->drawLine(lightSource, lightSource + Vertex(i, j, k).makeUnitVector() / 2, Color().WHITE);
			}
		}
	}
}

void Shader::moveLight(const Vertex& newPos){
	lightSource = newPos;
	std::cout << lightSource << std::endl;
}