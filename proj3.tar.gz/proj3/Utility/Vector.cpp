#include <memory>
#include "Vector.h"



Vector::Vector(const Vertex& v1, const Vertex &v2){
	position = v1;
	direction = v2;

}

Vector::Vector(const Vector &v){
	position = v.position;
	direction = v.direction;
}

Vector::~Vector(){

}
 
void Vector::makeUnitVector(){
	
}