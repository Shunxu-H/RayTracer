#include <iostream>
#include <vector>
#include <cstdio>
#include <ctgmath>
#include <memory>
#include "Mouse.h"
#include "Config.h"
#include "Geometry.h"
#include "Shader.h"
#include "Matrix.h"
#include "WindowManager.h"
#include "Index.h"
#include "Edge.h"
#include "OrthoView.h"

extern WindowManager* winMan;
extern Config progConfig;
extern Geometry* vertexBuffer;
extern Shader* shader;

#define _USE_MATH_DEFINES

Mouse::Mouse(){
	view = nullptr;
	for ( int i = 0; i < 3; i++){
		curPos[i] = 0.0f;
		prevPos[i] = 0.0f;
	}
}

Mouse::Mouse( OrthoView* _v):view(_v){

	for ( int i = 0; i < 3; i++){
		curPos[i] = 0.0f;
		prevPos[i] = 0.0f;
	}
}


void Mouse::mouseHold(int x, int y)
{
	
	int h = view->getHeight();

	if(progConfig.opMode == DRAWING){
		if ( vertexBuffer->size() > 0){
			vertexBuffer->pop();
			std::shared_ptr<Vertex> v (new Vertex(x, h- y, 0));
			v->toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			*vertexBuffer += v;
		}
	}
	else if (progConfig.opMode == MOVING){

		view->coordLoc[view->axis1] -= (x - prevPos[view->axis1])/view->pixelsPerUnit;
		view->coordLoc[view->axis2] -= (y - prevPos[view->axis2])/view->pixelsPerUnit;
		prevPos[view->axis1] = x;
		prevPos[view->axis2] = y; 
		//view->x = 
	}
	else if (progConfig.opMode == TRANSFORM)
	{
		if(!progConfig.isValidSelection())
			return;


		Vertex v1(prevPos[X], prevPos[Y], prevPos[Z]);
		Vertex v2;

		v2[view->axis1] = x;
		v2[view->axis2] = y;

		if (progConfig.transMode == TRANSLATE){
			//m.print();
			//std::cout << v1 << "||" << v2 << std::endl;
			Matrix m;
			v1.toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			v2.toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			m.makeTranslationMatrix(v2.getX() - v1.getX(), v2.getY() - v1.getY(),  v2.getZ() - v1.getZ());
			Geometry* geo = shader->getCurSelection();
			if(geo != nullptr){
				geo->transform(m);
			}
		}
		else if (progConfig.transMode == ROTATE){

			Edge rotAxis( std::shared_ptr<Vertex>(new Vertex(*shader->rotationVector.getHead())),
						  std::shared_ptr<Vertex>(new Vertex(*shader->rotationVector.getTail())));
			rotAxis.makeUnitVector();

			Vertex centroid (shader->nGetGeo(progConfig.curSelected)->getCentroid());
			Vertex v1(prevPos[X], prevPos[Y], 0);
			Vertex v2(x, y, 0);

			v1.toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			v2.toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			
			//float alpha;

			Matrix tm, m2XZ, m2Z, m, rm2Z, rm2XZ, rtm;

			// make translation matrix
			tm.makeTranslationMatrix(-rotAxis.getHead()->getX(),-rotAxis.getHead()->getY(),-rotAxis.getHead()->getZ());
			// makr reverse translation matrix
			rtm.makeTranslationMatrix(rotAxis.getHead()->getX(),rotAxis.getHead()->getY(),rotAxis.getHead()->getZ());

			rotAxis.getHead()->transform(tm);
			rotAxis.getTail()->transform(tm);

			float alpha2XZ = acos( (rotAxis.getTail()->getZ() - rotAxis.getHead()->getZ()) / 
							 sqrt( pow( rotAxis.getTail()->getY() - rotAxis.getHead()->getY(), 2) +
						     	   pow( rotAxis.getTail()->getZ() - rotAxis.getHead()->getZ(), 2) ) ); 
			// rotation/reverse rotation to XZ plane
			m2XZ.makeBaseRotMatrix(alpha2XZ, X);
			rm2XZ.makeBaseRotMatrix(-alpha2XZ, X);

			if (std::isnan(alpha2XZ) ){

				std::cout << "a" << alpha2XZ  << std::endl;
				alpha2XZ = 0.0f;

			}
			rotAxis.getHead()->transform(m2XZ);
			rotAxis.getTail()->transform(m2XZ);

			float alpha2Z = -asin( rotAxis.getTail()->getX() - rotAxis.getHead()->getX() / 
									sqrt( pow( rotAxis.getTail()->getX() - rotAxis.getHead()->getX(), 2) +
									      pow( rotAxis.getTail()->getZ() - rotAxis.getHead()->getZ(), 2) ) ); 
			float alpha = atan( (centroid.getY() - v1.getY())/(v1.getX() - centroid.getX()) ) + atan( (v2.getY() - centroid.getY())/(v2.getX() - centroid.getX()) );
			
			if (std::isnan(alpha2Z) ){
				alpha2Z = 0.0f;

			}

			// rotation/reverse rotation to Z axis
			m2Z.makeBaseRotMatrix(alpha2Z, Y);
			rm2Z.makeBaseRotMatrix(-alpha2Z, Y);
			m.makeBaseRotMatrix(alpha, Z);


			Matrix M = rtm*rm2XZ*rm2Z*m*m2Z*m2XZ*tm;

			shader->nGetGeo(progConfig.curSelected)->transform(M);
		}
		else if (progConfig.transMode == SCALE){
			Vertex centroid (shader->nGetGeo(progConfig.curSelected)->getCentroid());

			v1.toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			v2.toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			//centroid.toCOORDS();

			if (!(v1[view->axis1] == 0 || v1[view->axis2] == 0)){
				float alpha[3];

				alpha[0] = 1.0f;alpha[1] = 1.0f;alpha[2] = 1.0f;
				alpha[view->axis1] = v2[view->axis1]/v1[view->axis1];
				alpha[view->axis2] = v2[view->axis2]/v1[view->axis2];
				
				//centroid.print();

				Matrix m1, m2, m3;

				m1.makeTranslationMatrix(-centroid.getX(), -centroid.getY(), -centroid.getZ());

				m2.makeScalingMatrix(alpha[0], alpha[1], alpha[2]);
				m3.makeTranslationMatrix(centroid.getX(), centroid.getY(), centroid.getZ());



				shader->nGetGeo(progConfig.curSelected)->transform(m3*m2*m1);
			}

		}

		prevPos[view->axis1] = x;
		prevPos[view->axis2] = y; 
	}

	
	glutPostRedisplay();
}

void Mouse::mouseClick(int button, int state, int x, int y) {
	//  GLUT_LEFT_BUTTON, GLUT_MIDDLE_BUTTON, or GLUT_RIGHT_BUTTON
	// GLUT_UP or GLUT_DOWN
	if (state == GLUT_UP) {
		//glutPostRedisplayView();
		return;
	}
	//std::cout << button << " " << state <<  "X: " << x << "; " << "Y: " << y << std::endl;



	if (button == GLUT_LEFT_BUTTON){

		if (progConfig.opMode == DRAWING){
			if (state == GLUT_DOWN){
			 	//std::cout << "Coordinate:" << x << " " << y << std::endl;
			 	std::shared_ptr<Vertex> newV ( new Vertex(x, y, 0) );
			 	newV->toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());
			 	//newV->print();
			 	*vertexBuffer+=newV;
			}
		}
		else if(progConfig.opMode == MOVING){

			prevPos[view->axis1] = x;
			prevPos[view->axis2] = y;

		}
		else if(progConfig.opMode == CLIPPING){
			Vertex v(x, y, 0);
			v.toCOORDS(view->getPixelPerUnit(), view->getX(), view->getY(), view->getZ());

			if (progConfig.curSelected != -1 || shader->nGetGeo(progConfig.curSelected) != nullptr){
				shader->nGetGeo(progConfig.curSelected)->clip(v);
			}
			else{
				if (shader->size() > 0){
					progConfig.curSelected = 0;
					shader->nGetGeo(progConfig.curSelected)->clip(v);
				}
			}


			// change dimensionality of clippint method
			if (progConfig.clipMode == LEFT)
				progConfig.opMode = DRAWING;
			else 
				progConfig.clipMode = static_cast<ClipMode>(static_cast<int>(progConfig.clipMode)+1);
		}
		else if (progConfig.opMode == TRANSFORM)
		{

			prevPos[view->axis1] = x;
			prevPos[view->axis2] = y;
			if ( shader->nGetGeo(progConfig.curSelected) != nullptr)
				shader->nGetGeo(progConfig.curSelected)->updateCentroid();
		}
	}
	else if (button == 3 || button == 4) // It's a wheel up
	{

		//std::cout << "Mode: " << progConfig.clipMode << std::endl;
		if (progConfig.opMode == CLIPPING){
			progConfig.clipMode = static_cast<ClipMode>
				((button == 3)? (static_cast<int>(progConfig.clipMode + 1 ) % 4) : 
					(progConfig.clipMode == UP)? LEFT : ((static_cast<int>(progConfig.clipMode) - 1 ) )); 
		}
		else if(progConfig.opMode == TRANSFORM){
			if (shader->size() > 0){
				progConfig.curSelected = (button == 3)? ((progConfig.curSelected + 1 )%shader->size() ):
														(( (progConfig.curSelected == 0)? (shader->size() -1): ((progConfig.curSelected - 1)  )%shader->size()) );
			}
		}
		else if(progConfig.opMode == MOVING){
			// if wheel up
			if( button == 3 )
				view->pixelsPerUnit *= 1.05;
			else
				view->pixelsPerUnit *= 0.95;

		}
	}
	// right click
	else if (button == GLUT_RIGHT_BUTTON)
	{
		if(progConfig.opMode == MOVING){
			winMan->reshapeWindows();

		}
	}

	glutPostRedisplay();

}


void Mouse::mouseHover(int x, int y){

	curPos[view->axis1] = x;
	curPos[view->axis2] = y;
	//std::cout << x << " " << y << std::endl;
	if (progConfig.opMode == CLIPPING)
		glutPostRedisplay();
}


void Mouse::viewClipLine(){
	if (progConfig.opMode != CLIPPING)
		return;

	//std::cout << glutGetWindow() << std::endl;

	if(progConfig.clipMode == UP)
		clipUP();
	else if(progConfig.clipMode == DOWN)
		clipDOWN();
	else if(progConfig.clipMode == LEFT)
		clipLEFT();
	else if(progConfig.clipMode == RIGHT)
		clipRIGHT();
	
}


void Mouse::clipUP(){
	int h = view->getHeight();

	progConfig.clipMode = UP;

	view->drawHorizontal(h-curPos[Y]+30, progConfig.color.getColor(0.75f,0.75f,0.75f));
	view->drawHorizontal(h-curPos[Y]+20, progConfig.color.getColor(0.5f,0.5f,0.5f));
	view->drawHorizontal(h-curPos[Y]+10, progConfig.color.getColor(0.25f,0.25f,0.25f));
	view->drawHorizontal(h-curPos[Y]);

}

void Mouse::clipDOWN(){

	int h = view->getHeight();

	progConfig.clipMode = DOWN;
	view->drawHorizontal(h-curPos[Y]-30, progConfig.color.getColor(0.75f,0.75f,0.75f));
	view->drawHorizontal(h-curPos[Y]-20, progConfig.color.getColor(0.5f,0.5f,0.5f));
	view->drawHorizontal(h-curPos[Y]-10, progConfig.color.getColor(0.25f,0.25f,0.25f));
	view->drawHorizontal(h-curPos[Y]);


}


void Mouse::clipLEFT(){


	progConfig.clipMode = LEFT;
	view->drawVertical(curPos[X]-30, progConfig.color.getColor(0.75f,0.75f,0.75f));
	view->drawVertical(curPos[X]-20, progConfig.color.getColor(0.5f,0.5f,0.5f));
	view->drawVertical(curPos[X]-10, progConfig.color.getColor(0.25f,0.25f,0.25f));
	view->drawVertical(curPos[X]);

}

void Mouse::clipRIGHT(){


	progConfig.clipMode = RIGHT;
	view->drawVertical(curPos[X]+30, progConfig.color.getColor(0.75f,0.75f,0.75f));
	view->drawVertical(curPos[X]+20, progConfig.color.getColor(0.5f,0.5f,0.5f));
	view->drawVertical(curPos[X]+10, progConfig.color.getColor(0.25f,0.25f,0.25f));
	view->drawVertical(curPos[X]);

}