#include <GL/glut.h>
#include <string>
#include <iostream>
#include "WindowManager.h"
#include "Keyboard.h"
#include "Cabinet.h"
#include "Shader.h"
#include "View.h"
#include "TextView.h"

extern Shader* shader;

void update();
void keyboardHandler(unsigned char key, int x, int y);
void keyboardReleaseHandler(unsigned char key, int x, int y);


int MARGIN = 20;

WindowManager::WindowManager(){
	views = nullptr;
}

WindowManager::WindowManager(int argc, char** argv, const std::string& title, int window_width, int window_height){
	mainWindowWidth = window_width;
	mainWindowHeight = window_height;
	numOfWindows = 5;

	glutInit(&argc, argv); 
	glutInitDisplayMode(GLUT_SINGLE); 

	//set window size to 200*200 
	glutInitWindowSize(window_width*3 + 4*MARGIN, window_height*2 + 3*MARGIN); 

	//set window position 
	glutInitWindowPosition(400, 200);
	//create and set main window title 
	mainWindowContex = glutCreateWindow(title.c_str()); 
	glutDisplayFunc(::update);

	glClear(GL_COLOR_BUFFER_BIT); 




	views = new View*[numOfWindows];

	views[XY] 			= new OrthoView (XY, mainWindowContex, MARGIN, 					MARGIN, window_width, window_height);
	views[ZY] 			= new OrthoView (ZY, mainWindowContex, window_width + MARGIN*2 , 	MARGIN, window_width, window_height);
	views[XZ] 			= new OrthoView (XZ, mainWindowContex, MARGIN, window_height + MARGIN*2, window_width , window_height);
	views[CABINET] 		= new Cabinet 	(CABINET, mainWindowContex, window_width + MARGIN*2, window_height + MARGIN*2, window_width, window_height);
	views[TEXTVIEW] 	= new TextView 	(TEXTVIEW, mainWindowContex, window_width*2 + MARGIN*3, MARGIN, window_width, window_height*2);
	
	//viewss[4] = new views(mainWindowContex, 0, 0, window_width, window_height);



	glClearColor(0, 0, 0, 0); 
	//clears the buffer of OpenGL //sets views function 
}

WindowManager::~WindowManager(){
	if (views != nullptr){
		for (int i = 0; i < 4; i++)
			delete (views[i]);
		delete[] (views);
	}
}

WindowManager::WindowManager(const WindowManager& rhs){
	mainWindowWidth = rhs.mainWindowWidth;
	mainWindowHeight = rhs.mainWindowHeight;
	views = rhs.views;
	mainWindowContex = rhs.mainWindowContex;
}

void WindowManager::updateWindow(const int & winID){

	View* curD = (*this)[winID];
	if (curD != nullptr){
		if ( curD == views[CABINET])
			((Cabinet*)curD)->updateWindow();
		else if ( curD == views[TEXTVIEW]){
			//std::cout << "here" << std::endl;
			((TextView*)curD)->updateWindow();
		}
		else
			curD->updateWindow();
	}
	//viewss[4]->updateWindow()
}

void WindowManager::reshapeWindows(){
	Vertex min(shader->getMinX(), shader->getMinY(), shader->getMinZ());
	Vertex max(shader->getMaxX(), shader->getMaxY(), shader->getMaxZ());

	for( int i = 0; i < 3; i++ )
		static_cast<OrthoView*>(views[i])->reshapeWindow(min, max);

}
	


void WindowManager::fillPolygon(Geometry* geo){
	for ( int i = 0; i < numOfWindows; i++)
		views[i]->fillPolygon(geo);
}

void WindowManager::drawLineDDA(const Vertex &v1, const Vertex &v2, float *color){

	for ( int i = 0; i < numOfWindows; i++){
		if (views[i] == views[CABINET])
			((Cabinet*)views[i])->drawLineDDA(*v1, *v2, color);
		else
			views[i]->drawLineDDA(*v1, *v2, color);
	}
}

void WindowManager::drawLineBSH(const Vertex &v1, const Vertex &v2, float*color){

	for ( int i = 0; i < 4; i++)
		views[i]->drawLineBSH(v1, v2, color);
}

void WindowManager::drawLine( const std::vector<Vertex> &vertexBuffer, float* color){
	
	for ( int i = 0; i < 4; i++)
		views[i]->drawLine(vertexBuffer,color);

}


void WindowManager::setPix(const Vertex* v,  float* color){
	
	for ( int i = 0; i < 4; i++)
		views[i]->setPix( v, color);
}

void WindowManager::setPix(const int& x, const int& y,  float* color){

	for ( int i = 0; i < 4; i++)
		views[i]->setPix(x, y, color);
}


void WindowManager::keyboardHandler(const unsigned char &key, const int &x, const int &y)const{
	keyboard->keyboardHandler(key, x, y);
}
void WindowManager::keyboardReleaseHandler(const unsigned char &key, const int &x, const int &y)const{
	keyboard->keyboardReleaseHandler(key, x, y);
}


int WindowManager::getWindowID(View* d) {
	for (int i = 1; i < 4; i++)
		if (d == views[i])
			return i;

	return -1;
}

View* WindowManager::operator[](const int& windowID)const { 
	for ( int i = 0; i < numOfWindows; i++) 
		if (views[i]->windowContext == windowID) 
			return views[i];  

	return nullptr; 
}
