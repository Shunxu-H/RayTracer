#include <iostream>
#include <GL/glut.h>
#include "Cabinet.h"
#include "Config.h"
#include "Shader.h"
#include "Geometry.h"
#include "Edge.h"
#include "Mouse.h"

extern Config progConfig; 
extern Shader* shader;
extern Geometry* vertexBuffer;

void Cabinet::updateWindow(){

	glClear(GL_COLOR_BUFFER_BIT); 
	glLoadIdentity();
	clear();

	// draw coordinate
	drawAxis();

	shader->drawAll();
	View::drawOutline();

	if( progConfig.opMode == CLIPPING )
		mouse->viewClipLine();
	
	glDrawPixels(width, height, GL_RGB, GL_FLOAT, PixelBuffer.get());
	
	glutPostRedisplay();
}

void Cabinet::drawLineDDA(Vertex v1, Vertex v2, float* color){

	Matrix cabinetMatrix;
	cabinetMatrix.makeCabinet();
	v1.transform(cabinetMatrix);
	v2.transform(cabinetMatrix);
	OrthoView::drawLineDDA(v1, v2, color );
}

void Cabinet::drawLineBSH(const std::shared_ptr<Vertex> &v1, const std::shared_ptr<Vertex> &v2, float* color){

}

void Cabinet::drawAxis(){
	Vertex origin(0, 0, 0);
	origin.toPXLPOS(pixelsPerUnit, coordLoc[X], coordLoc[Y], coordLoc[Z]);
	drawVertical(origin[axis1], progConfig.COLOR_axis);
	drawHorizontal(origin[axis2], progConfig.COLOR_axis);
	
	Vertex zMin (0, 0, -100);
	Vertex zMax (0, 0, 100);

	drawLineDDA(zMin, zMax, progConfig.COLOR_axis);
}
