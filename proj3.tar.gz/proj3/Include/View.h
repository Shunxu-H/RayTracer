#ifndef VIEW_H
	#define VIEW_H

#include <GL/glut.h>
#include <string>
#include <utility>
#include <vector>

#include <memory>
#include "Index.h"
#include "Vertex.h"
#include "AEL.h"

class Mouse;
class Keyboard;
class Face;

class WindowManager;

enum ViewType
{
	XY, 
	ZY,
	XZ,
	CABINET,
	TEXTVIEW

};


class View
{
public:
	View(){};
	View(const ViewType &vt, const int& mainContext, const int& loc_x, const int& loc_y, const int& window_width, const int& window_height);//, int canvas_width, int canvas_height);
	~View();

	virtual void fillPolygon(Geometry &geo, const float *);
	virtual void fillPolygons(std::vector<Geometry*> &geo){}
	
	virtual void halfToning(Geometry &geometries);
	void drawLineBSH(const std::shared_ptr<Vertex> &v1, const std::shared_ptr<Vertex> &v2, float*);
	virtual void drawLineDDA(Vertex v1, Vertex v2, const float*) = 0;
	virtual void drawAxis() = 0;
	void drawLine( const std::vector<Vertex> &vertexBuffer, const float*);
	void drawHorizontal(const int &y, const float* =nullptr);
	void drawVertical(const int &x, const float* =nullptr);

	void drawHorizontal(const int &y, const int &x1, const int &x2, const float* =nullptr);
	void drawVertical(const int &x,const int &y1, const int &y2, const float* =nullptr);

	void setPix(const Vertex*, const float*);
	void setPix(const int&, const int&, const float*);
	void clear();

	virtual void updateWindow() = 0;
	void drawOutline();

	inline int getHeight()const { return width; };
	inline int getWidth()const { return height; };
	inline float* getBuffer()const { return PixelBuffer.get(); };

	inline float getX()const { return coordLoc[X]; };
	inline float getY()const { return coordLoc[Y]; };
	inline float getZ()const { return coordLoc[Z]; };
	inline float getPixelPerUnit()const { return pixelsPerUnit; };
	void mouseClick(const int& button, const int& state, const int& x, const int& y);
	void mouseHold(int x, int y);
	void mouseHover(int x, int y);

	void keyboardHandler(unsigned char key, int x, int y);
	void keyboardReleaseHandler(unsigned char key, int x, int y);

	//void reshapeWindow(const Vertex& min, const Vertex& max);

	friend Mouse;

protected:

	std::unique_ptr<float> PixelBuffer;

	ViewType viewType;
	int windPos[2]; // coordinate of the current window w.r.t the main window
	float coordLoc[3];
	int windowContext;
	float pixelsPerUnit; 
	float width, height;
	static Keyboard keyboard; 
	void drawLineDDA(float x1, float y1, float x2, float y2, const float* color);
	Vertex interpolate(const float& startPr, const float& endPr, const float& x, const Vertex &startColor, const Vertex &endColor)const;
	Mouse *mouse;

private:
	friend class WindowManager;

	void init();
	// 1 unit in coordinate lengthes 'coor2pixel' pixel in OrthoView;
};



#endif 
