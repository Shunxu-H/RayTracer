#ifndef OBJECT_H
	#define OBJECT_H

class Object
{
public:
	
protected:

private:

};



	#endif