#ifndef MOUSE_H
	#define MOUSE_H

//#include "OrthoView.h"
#include "Vertex.h"

class View;

class OrthoView;
class Mouse{
public:
	Mouse();
	Mouse( OrthoView* _v);
	~Mouse(){} ;

	void mouseHold(int x, int y);
	void mouseClick(int button, int state, int x, int y);
	void mouseHover(int x, int y);
	void viewClipLine();

protected:


private:
	OrthoView* view;
	int curPos[3];
	int prevPos[3];
	void clipUP();
	void clipDOWN();
	void clipLEFT();
	void clipRIGHT();

	inline bool sameSign(float a, float b) {return a*b >= 0.0f;};


};



	#endif