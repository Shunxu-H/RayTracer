#ifndef CONFIG_H
	#define CONFIG_H

#include "Color.h"
class Geometry;
enum LineAlg
{
	DDA, // Digital Differential Analyzer
	BSH // Brosenham's algorithm
};

enum OpMode
{
	SELECTING,
	DRAWING,
	MOVING,
	INSERT,
	CLIPPING,
	TRANSFORM
};

enum ClipMode
{
	UP,
	RIGHT,
	DOWN,
	LEFT
};

enum ColorMode
{
	RGB,
	RGBA
};

enum FillMode
{
	HALFTONE,
	OUTLINE,
	FILL,
	COUNT
};

enum RenderMode
{
	NORMAL,
	HIGHLIGHT
};

enum TransfromMode
{
	UNSET,
	TRANSLATE,
	SCALE,
	ROTATE
};

struct Config
{
	Color color;
	LineAlg lineAlg;
	OpMode opMode;
	FillMode fillMode;
	ClipMode clipMode;
	RenderMode renderMode;
	TransfromMode transMode;
	int curSelected;
	bool showNormal;
	bool showEdge;
	float COLOR_bg[4];
	float COLOR_outline[4];
	float COLOR_text[4];
	float COLOR_regStroke[4];
	float COLOR_hlStroke[4];
	float COLOR_fill[4];
	float COLOR_rotVec[4];
	float COLOR_axis[4];


	Config();
	bool isValidSelection();
};


	#endif 
