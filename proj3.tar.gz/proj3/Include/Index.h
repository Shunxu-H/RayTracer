#ifndef INDEX_H
	#define INDEX_H


enum INDEX
{
	X,
	Y,
	Z
};

enum COLORINDEX
{
	R,
	G,
	B
};

	#endif
