#ifndef VECTOR_H
	#define VECTOR_H

#include <memory>
#include "Vertex.h"

class Vector{
public:
	Vector(){}
	Vector(const Vertex&, const Vertex&);
	Vector(const float& x1, const float& y1, const float& z1, const float& x2, const float& y2, const float& z2);
	Vector(const Vector &v);
	~Vector();


protected:

private:
	void makeUnitVector();
	Vertex position;
	Vertex direction;

};


	#endif 