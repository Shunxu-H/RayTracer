#ifndef VERTEX_H
	#define VERTEX_H

#include <iostream>
#include <cstring>
#include <memory>
#include "Index.h"
#include "Matrix.h"
//class Geometry;
//#include "OrthoView.h"
class Geometry;

class Vertex: public Matrix
{
public:
	//Vertex():Matrix(3, 1){data[0][0] = 0.0f; data[0][1] = 0.0f; data[0][2] = 0.0f; };
	Vertex(const float &_x=0.0f, const float &_y=0.0f, const float &_z=0.0f);
	Vertex(const Matrix &rhs);
	Vertex(const Vertex &rhs);
	//Vertex operator=(const Vertex& rhs){ return Vertex(rhs); }
	~Vertex();
	//inline std::pair<int, int> toOrthoViewUnit();

	inline float getX()const { return data[0][X]; };
	inline float getY()const { return data[0][Y]; };
	inline float getZ()const { return data[0][Z]; };
	inline void setX(const float& _x){ data[0][X] = _x; };
	inline void setY(const float& _y){ data[0][Y] = _y; };
	inline void setZ(const float& _z){ data[0][Z] = _z; };


	double length();
	Vertex makeUnitVector();


	inline bool operator==(const Vertex& rhs)const{return memcmp(data[0], rhs.data[0], sizeof(float[3])) == 0 ;}
	inline bool operator!=(const Vertex& rhs)const{return !((*this) == rhs) ;}
	inline float& operator[](const INDEX & index){return data[0][static_cast<int>(index)];};
	inline float operator[](const INDEX & index)const {return data[0][static_cast<int>(index)];};
	inline float& operator[](const unsigned int & index){return data[0][index];};
	inline float operator[](const unsigned int & index)const {return data[0][index];};



	Vertex operator*(const Vertex& rhs)const { return static_cast<Matrix>(*this) * static_cast<Matrix>(rhs); }
	Vertex operator*(const float& n)const { return static_cast<Matrix>(*this) * n; }
	Vertex operator/(const float& n)const { return static_cast<Matrix>(*this) / n; }
	Vertex operator+(const Vertex& rhs)const { return static_cast<Matrix>(*this) + static_cast<Matrix>(rhs); }
	Vertex operator+(const float& n)const { return static_cast<Matrix>(*this) + n; }
	Vertex operator-(const Vertex& rhs)const { return static_cast<Matrix>(*this) - static_cast<Matrix>(rhs); }
	Vertex operator-(const float& n)const { return static_cast<Matrix>(*this) - n; }
	Vertex operator-()const { return -static_cast<Matrix>(*this); }
	Vertex transpose()const { return static_cast<Matrix>(*this).transpose(); }
	float dot(const Vertex& v)const{ return (this->transpose()*v).data[0][0]; };
	Vertex times(const Vertex& rhs)const { return static_cast<Matrix>(*this).times( static_cast<Matrix>(rhs) ); }


	Vertex cross(const Vertex& rhs)const;

	void toCOORDS(const float&, const float&, const float&, const float&);
	void toPXLPOS(const float&, const float&, const float&, const float&);
	// Vertex operator*(const float&)const;
	// Vertex operator+(const Vertex&)const;
	// Vertex operator-(const Vertex&)const;
	
	Vertex inCOORDS(const float& pixelUnit, const float &w_x, const float& w_y, const float& w_z)const;
	Vertex inPXLPOS(const float& pixelUnit, const float &w_x, const float& w_y, const float& w_z)const;

	void transform(const Matrix& m);

	friend std::ostream& operator<< (std::ostream& stream, const Vertex& matrix);
        
    Vertex getColor()const;
    void setColor(const float& r , const float& g, const float& b);
	void setColor(const Vertex& c);
	

protected:


private:
	friend Geometry;
	float color[3];
	//Vertex* color;
	//int test;
	//UnitType type;
};



	#endif
