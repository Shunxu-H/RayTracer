#ifndef FACE_H
	#define FACE_H

#include <vector>
#include <memory>
#include "Geometry.h"
#include "Index.h"
class Edge;
class AEL;

class Face
{
public:
	Face();
	Face(const Face& f);
	void addV(std::shared_ptr<Vertex> v);

	std::shared_ptr<Vertex> getV(const unsigned int & index)const;
	~Face();

	bool hasVertex(const Vertex&)const;
	int getVerticesCnt()const{return vertices.size();}

	std::vector<AEL*> getAELs(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z, const INDEX &, const INDEX &)const;

	Face inPXLCOORD(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z)const;
	void print();
	Vertex getNormalVector();
	Vertex getCentroid();
	const std::vector<std::shared_ptr<Vertex>>& getVertices()const{ return vertices;};

protected:

private:
	void toPXLPOS(const float& pixelUnit, const float& w_x, const float& w_y, const float& w_z);
	std::vector<std::shared_ptr<Vertex>> vertices;

};



	#endif
