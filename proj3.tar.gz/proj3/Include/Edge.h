#ifndef EDGE_H
	#define EDGE_H
#include <memory>
#include "Vertex.h"

class Edge{
public:
	Edge(){};
	Edge(const Edge& e);
	inline Edge(std::shared_ptr<Vertex> h, std::shared_ptr<Vertex> t):head(h), tail(t){};
	inline std::shared_ptr<Vertex> getHead()const {return head;}
	inline std::shared_ptr<Vertex> getTail()const {return tail;}
	
	inline void setHead(const float &x, const float &y, const float &z ) { head->setX(x);head->setY(y); head->setZ(z);}
	inline void setTail(const float &x, const float &y, const float &z ) { tail->setX(x);tail->setY(y); tail->setZ(z);}

	void makeUnitVector();
	double length();
protected:

private:
	std::shared_ptr<Vertex> head;
	std::shared_ptr<Vertex> tail;
};
	#endif