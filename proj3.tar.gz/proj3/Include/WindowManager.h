#ifndef WINDOWMANAGER_H
	#define WINDOWMANAGER_H

//#include "View.h"
#include <vector>
#include <memory>
class View;
class Vertex;
class Geometry;
class Face;

class Keyboard;
class WindowManager
{
public:
	WindowManager();
	WindowManager(int argc, char** argv, const std::string& title, int window_width, int window_height);
	WindowManager(const WindowManager&);
	~WindowManager();

	inline int getHeight()const{return mainWindowHeight;}
	inline int getwidth()const{return mainWindowWidth;}
	void updateWindow(const int & winID);

	void setPix(const Vertex*, float*);
	void setPix(const int&, const int&, float*);
	
	void fillPolygon(Geometry &geometries, const float*);

	void fillPolygons(std::vector<Geometry*> &geos);
	void halfToning(Geometry &geometries);

	void drawLine(const Vertex &v1, const Vertex &v2, float*);
	void drawLine( const std::vector<Vertex> &vertexBuffer, float*);

	View* operator[](const int& windowID)const;
	int getWindowID(View* d);

	void keyboardHandler(const unsigned char &key, const int &x, const int &y)const;
	void keyboardReleaseHandler(const unsigned char &key, const int &x, const int &y)const;

	void reshapeWindows();
	
protected:


private:
	int numOfWindows;
	int mainWindowWidth;
	int mainWindowHeight;
	View** views;
	Keyboard* keyboard;
	int mainWindowContex;

	void drawLineDDA(const Vertex &v1, const Vertex &v2, float*);
	void drawLineBSH(const Vertex &v1, const Vertex &v2, float*);
};





	#endif