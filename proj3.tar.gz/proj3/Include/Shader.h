#ifndef SHADER_H
	#define SHADER_H

#include <vector>
#include <string>
#include <memory>
#include "Edge.h"
#include "Vector.h"

class Coordinate;
class Geometry;
class Shader
{
public:
	Shader(const std::string& file="./data/temp.gmt");
	~Shader();
	void addGeom( Geometry* newG );
	void clear();
	void save(const std::string& fileName);
	Geometry* getCurSelection()const;
	void deleteGeo(Geometry* geo)const;
	void print()const;
	void deleteGeo(Geometry* g);
	Vertex getColor(const Vertex& v)const;

	inline unsigned int size()const{ return geometries.size(); };
	Edge rotationVector;

	float getMaxX()const;
	float getMinX()const;
	float getMaxY()const;
	float getMinY()const;
	float getMaxZ()const;
	float getMinZ()const;
	int geoGetN(const Geometry* geoPtr)const;
	Geometry* nGetGeo(const unsigned int &index)const;
	void loadFile (const std::string& _fileName="");
	void drawAll();
	float getColorNormalizeRate()const;

	void normalizeColors(const float& colorRate )const;

	void drawLight()const;
	void moveLight(const Vertex& newPos);

protected:


private:
	std::string fileName;
	std::vector<Geometry*> geometries;
	Vertex viewPtr;
	Vertex lightSource;
	Geometry *curRendering;
	Vertex getNormalVector(const Vertex& v)const;	


};


	#endif